# DataPoints represent output execution of Python code, prior to everything else (serialization or preview format)
# DataPoints are defined per Chalk'it scope.
