from taipy_designer import *


text = "this is page 2"


page = DesignerPage("p_page2.xprjson", designer_mode=True)
