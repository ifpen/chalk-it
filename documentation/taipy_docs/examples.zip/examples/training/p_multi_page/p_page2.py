from chlkt import *


text = "this is page 2"


page = ChalkitPage("p_page2.xprjson", designer_mode=True)